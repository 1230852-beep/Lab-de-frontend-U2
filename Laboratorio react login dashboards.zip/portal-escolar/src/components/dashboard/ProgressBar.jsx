// Reto 3: barra de progreso reutilizable. Recibe un porcentaje (0-100).
const ProgressBar = ({ percent, label }) => {
  const safePercent = Math.min(100, Math.max(0, percent));

  return (
    <div className="progress">
      {label && <span className="progress-label">{label}</span>}
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${safePercent}%` }}>
          {safePercent}%
        </div>
      </div>
    </div>
  );
};

export default ProgressBar;
