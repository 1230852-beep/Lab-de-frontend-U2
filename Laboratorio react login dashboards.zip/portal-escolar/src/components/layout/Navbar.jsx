import Button from '../common/Button';

// Reto 2: la prop logoutVariant permite cambiar el color del botón (por defecto 'secondary')
const Navbar = ({ user, onLogout, logoutVariant = 'secondary' }) => {
  const roleLabel = user.role === 'admin' ? 'Administrador' : 'Usuario';

  return (
    <header className="navbar">
      <span className="navbar-brand">Portal Escolar</span>
      <div className="navbar-user">
        <span>{user.name} ({roleLabel})</span>
        <Button variant={logoutVariant} onClick={onLogout}>
          Cerrar sesión
        </Button>
      </div>
    </header>
  );
};

export default Navbar;
